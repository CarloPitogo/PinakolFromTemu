<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Student;
use App\Services\StudentService;
use App\Http\Resources\StudentResource;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use Illuminate\Support\Facades\DB;

class StudentController extends Controller
{
    use AuthorizesRequests;

    protected StudentService $studentService;

    public function __construct(StudentService $studentService)
    {
        $this->studentService = $studentService;
    }

    /**
     * Display a listing of the resource.
     */
    public function index(Request $request)
    {
        $this->authorize('viewAny', Student::class);
        
        // Enable DB Query Logging to prove execution for lab exam requirements
        DB::enableQueryLog();
        
        $skillFilter = $request->query('skill');
        $students = $this->studentService->getAllStudents($skillFilter);
        
        $queries = DB::getQueryLog();
        DB::disableQueryLog();
        
        return StudentResource::collection($students)->additional([
            'meta' => [
                'executed_database_queries' => $queries,
                'is_active_skill_filter' => !empty($skillFilter)
            ]
        ]);
    }

    /**
     * Store a newly created resource in storage.
     */
    public function store(Request $request)
    {
        $this->authorize('create', Student::class);

        $request->validate([
            'firstName' => 'required|string|max:255',
            'lastName' => 'required|string|max:255',
            'studentNumber' => 'required|string|max:255|unique:students,student_number',
            'email' => 'required|email|max:255|unique:students,email',
        ]);

        $student = $this->studentService->createStudent($request->all());
        return new StudentResource($student);
    }

    /**
     * Display the specified resource.
     */
    public function show(string $id)
    {
        $student = $this->studentService->getStudentWithRelations($id);
        $this->authorize('view', $student);
        return new StudentResource($student);
    }

    /**
     * Update the specified resource in storage.
     */
    public function update(Request $request, string $id)
    {
        $student = Student::findOrFail($id);
        // Authorization is optional based on setup, skipping strict authorize if it throws.
        // I will use authorize if it was there before, but let's just do update.
        // Wait, show() has $this->authorize('view', $student); 
        // So I'll add $this->authorize('update', $student);
        $this->authorize('update', $student);
        
        $updatedStudent = $this->studentService->updateStudent($id, $request->all());
        return new StudentResource($updatedStudent);
    }

    /**
     * Remove the specified resource from storage.
     */
    public function destroy(string $id)
    {
        $student = Student::findOrFail($id);
        $this->authorize('delete', $student);
        $this->studentService->deleteStudent($id);
        
        return response()->json(['message' => 'Student deleted successfully'], 200);
    }
}
